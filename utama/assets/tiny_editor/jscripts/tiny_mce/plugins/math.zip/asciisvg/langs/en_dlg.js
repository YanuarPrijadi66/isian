tinyMCE.addI18n('en.asciisvg_dlg',{
	title : 'Graph Editor'
});
